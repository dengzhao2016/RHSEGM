function [x_history, errors, rho_history, time_history, info] = HTS2025(F, P_C, params)
%HTS2025 Sunthrayuth et al., CNSNS 150 (2025), 108959, Algorithm 1.
% Inputs: F, P_C, and params.x0, rho0, mu, tol, max_iter.
% Outputs: iterates (one point per row), projected residuals, stepsizes,
%          elapsed times, and iteration/evaluation counts.
% Error = norm(x - P_C(x - F(x))); j=1 is the first completed update.

%% Parameters and initialization
params = algorithm_parameters(params);
if ~isfield(params,'alpha'), params.alpha = @(j)1/(j+1); end
if ~isfield(params,'theta'), params.theta = @(j)(j+1)^(-2.5); end
if ~isfield(params,'delta'), params.delta = @(j)-(j+1)^(-2.5); end
if ~isfield(params,'tau'), params.tau = min(1.5,(1+1/params.mu)/2); end
if ~isfield(params,'gamma'), params.gamma = .8; end
if ~isfield(params,'gamma_j'), params.gamma_j = @(j)1/(j+1); end
if ~isfield(params,'rho_j'), params.rho_j = @(j)1/(j+2)^2; end
tau = params.tau; gamma = params.gamma;
x = params.x0(:);
previous = x; previous2 = x; anchor = x;
lambda = params.rho0;
mu = params.mu;
max_iter = params.max_iter;
tol = params.tol;
dimension = numel(x);
x_history = zeros(max_iter+1, dimension);
errors = zeros(max_iter+1, 1);
rho_history = zeros(max_iter+1, 1);
time_history = zeros(max_iter+1, 1);
counter_history = zeros(max_iter+1, 3);
F_calls = 0; C_projections = 0; T_projections = 0;
iteration = 0;
% Initial residual; F(x) is reused in the first prediction step.
Fx = F(x); F_calls = F_calls + 1;
projected = P_C(x-Fx); C_projections = C_projections + 1;
x_history(1,:) = x';
errors(1) = norm(x-projected);
rho_history(1) = lambda;
time_history(1) = 0; % The common initial point is recorded at time zero.
counter_history(1,:) = [F_calls,C_projections,T_projections];

% Time completed updates, including their residual monitoring.
% The shared initial residual and history setup are outside this timer.
t_start = tic;

%% Main iteration
while iteration<max_iter && errors(iteration+1)>tol
    j = iteration+1;
    % Step 1: two inertial steps, v_j=x_j+theta_j(x_j-x_{j-1})
    %                              +delta_j(x_{j-1}-x_{j-2}).
    theta = params.theta(j); delta = params.delta(j); alpha = params.alpha(j);
    v = x+theta*(x-previous)+delta*(previous-previous2);
    if isequal(v,x), Fv = Fx;
    else, Fv = F(v); F_calls = F_calls+1; end

    % Step 2: prediction y_j=P_C(v_j-tau*lambda_j F(v_j)).
    y = P_C(v-tau*lambda*Fv); C_projections = C_projections+1;
    Fy = F(y); F_calls = F_calls+1;

    if isequal(v,y) || all(Fy==0)
        x_next = y; % Source stopping case: y is already a VI solution.
    else
        % Step 3: source residual direction and correction scalar eta_j.
        residual_direction = v-y-tau*lambda*(Fv-Fy);
        assert(norm(residual_direction)>0,'Zero HTS2025 denominator.');
        eta = (1-tau*mu)*norm(v-y)^2/norm(residual_direction)^2;

        % Step 4: supporting half-space and its projection.
        normal = v-tau*lambda*Fv-y;
        correction_point = v-gamma*lambda*eta*Fy;
        scale = max([1,norm(v),tau*lambda*norm(Fv),norm(y)]);
        correction = project_onto_halfspace(normal,y,correction_point,scale);
        T_projections = T_projections+1;

        % Step 5: fixed-anchor Halpern averaging.
        x_next = alpha*anchor+(1-alpha)*correction;
    end

    % Step 6: published nonmonotone adaptive stepsize.
    difference = norm(Fv-Fy);
    if difference>0
        lambda_next = min((params.gamma_j(j)+mu)*norm(v-y)/difference,...
            lambda+params.rho_j(j));
    else
        lambda_next = lambda+params.rho_j(j);
    end
    previous2 = previous; previous = x;
    x = x_next; lambda = lambda_next; iteration = iteration+1;
    % Store the completed iterate and its common residual.
    Fx = F(x); F_calls = F_calls + 1;
    projected = P_C(x-Fx); C_projections = C_projections + 1;
    x_history(iteration+1,:) = x';
    errors(iteration+1) = norm(x-projected);
    rho_history(iteration+1) = lambda;
    time_history(iteration+1) = toc(t_start);
    counter_history(iteration+1,:) = [F_calls,C_projections,T_projections];
end

%% Return the actual history (no padding after termination)
last = iteration+1;
x_history = x_history(1:last,:);
errors = errors(1:last);
rho_history = rho_history(1:last);
time_history = time_history(1:last);
info.method = 'HTS2025';
info.K = 0;
info.updates = iteration;
info.operatorCalls = F_calls;
info.constraintProjections = C_projections;
info.halfspaceProjections = T_projections;
info.residual = errors(end);
info.seconds = time_history(end);
info.success = errors(end)<=tol;
info.finalRho = rho_history(end);
info.counter_history = counter_history(1:last,:);
end

function params = algorithm_parameters(params)
%ALGORITHM_PARAMETERS Common defaults; no algorithmic iteration is hidden here.
assert(isfield(params,'x0'),'Supply the common initial point params.x0.');
if ~isfield(params,'mu'), params.mu = .8; end
if ~isfield(params,'rho0'), params.rho0 = 1; end
if ~isfield(params,'tol'), params.tol = 1e-6; end
if ~isfield(params,'max_iter'), params.max_iter = 4000; end
if ~isfield(params,'K'), params.K = 5; end
assert(params.mu>0 && params.mu<1,'mu must belong to (0,1).');
assert(params.rho0>0 && params.max_iter>=0,'Invalid stepsize or iteration cap.');
end

function projected = project_onto_halfspace(normal,base,point,scale)
%PROJECT_ONTO_HALFSPACE Projection onto {z: <normal,z-base> <= 0}.
% The scale argument only guards a numerically zero normal.
if nargin<4, scale = max([1,norm(base),norm(point)]); end
if norm(normal)<=1e-12*scale
    projected = point;
else
    projected = point-max(0,normal'*(point-base))/(normal'*normal)*normal;
end
end
