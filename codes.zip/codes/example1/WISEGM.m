function [x_history, errors, rho_history, time_history, info] = WISEGM(F, P_C, params)
%WISEGM Thong--Hieu--Rassias (2020), Algorithm 3.1.
% Inputs: F, P_C, and params.x0, rho0, mu, tol, max_iter.
% Outputs: iterates (one point per row), projected residuals, stepsizes,
%          elapsed times, and iteration/evaluation counts.
% Error = norm(x - P_C(x - F(x))); j=1 is the first completed update.

%% Parameters and initialization
params = algorithm_parameters(params);
if ~isfield(params,'inertial_cap'), params.inertial_cap = .3; end
x = params.x0(:);
previous = x;
rho = params.rho0;
mu = params.mu;
max_iter = params.max_iter;
tol = params.tol;
dimension = numel(x);
x_history = zeros(max_iter+1, dimension);
errors = zeros(max_iter+1, 1);
rho_history = zeros(max_iter+1, 1);
time_history = zeros(max_iter+1, 1);
counter_history = zeros(max_iter+1, 3);
F_calls = 0; C_projections = 0; T_projections = 0;
iteration = 0;
% Initial residual; F(x) is reused in the first prediction step.
Fx = F(x); F_calls = F_calls + 1;
projected = P_C(x-Fx); C_projections = C_projections + 1;
x_history(1,:) = x';
errors(1) = norm(x-projected);
rho_history(1) = rho;
time_history(1) = 0; % The common initial point is recorded at time zero.
counter_history(1,:) = [F_calls,C_projections,T_projections];

% Time completed updates, including their residual monitoring.
% The shared initial residual and history setup are outside this timer.
t_start = tic;

%% Main iteration
while iteration<max_iter && errors(iteration+1)>tol
    % Step 1: work point (inertial extrapolation, when present).
    j = iteration+1;
    difference_x = norm(x-previous);
    if difference_x>0
        alpha = min(params.inertial_cap,1/(j^2*difference_x^2));
    else
        alpha = params.inertial_cap;
    end
    work = x+alpha*(x-previous);
    if isequal(work,x)
        Fwork = Fx;
    else
        Fwork = F(work); F_calls = F_calls + 1;
    end

    % Step 2: y_j = P_C(work-rho_j*F(work)).
    if isequal(work,x) && rho==1
        y = projected;
    else
        y = P_C(work-rho*Fwork); C_projections = C_projections + 1;
    end
    Fy = F(y); F_calls = F_calls + 1;

    % Step 3: extragradient correction.
    % Supporting half-space T_j={z: <normal,z-y> <= 0}.
    normal = work-rho*Fwork-y;
    correction_point = work-rho*Fy;
    scale = max([1,norm(work),rho*norm(Fwork),norm(y)]);
    d = project_onto_halfspace(normal,y,correction_point,scale);
    T_projections = T_projections + 1;

    % Step 4: update the next stepsize, using the current correction.
    % Adaptive stepsize for the NEXT iteration.
    difference = norm(Fwork-Fy);
    if difference>0
        rho_next = min(mu*norm(work-y)/difference,rho);
    else
        rho_next = rho;
    end

    % Step 5: averaging/update of x_{j+1}.
    x_next = d;
    previous = x;
    x = x_next; rho = rho_next; iteration = iteration+1;
    % Store the completed iterate and its common residual.
    Fx = F(x); F_calls = F_calls + 1;
    projected = P_C(x-Fx); C_projections = C_projections + 1;
    x_history(iteration+1,:) = x';
    errors(iteration+1) = norm(x-projected);
    rho_history(iteration+1) = rho;
    time_history(iteration+1) = toc(t_start);
    counter_history(iteration+1,:) = [F_calls,C_projections,T_projections];
end

%% Return the actual history (no padding after termination)
last = iteration+1;
x_history = x_history(1:last,:);
errors = errors(1:last);
rho_history = rho_history(1:last);
time_history = time_history(1:last);
info.method = 'WISEGM';
info.K = 0;
info.updates = iteration;
info.operatorCalls = F_calls;
info.constraintProjections = C_projections;
info.halfspaceProjections = T_projections;
info.residual = errors(end);
info.seconds = time_history(end);
info.success = errors(end)<=tol;
info.finalRho = rho_history(end);
info.counter_history = counter_history(1:last,:);
end

function params = algorithm_parameters(params)
%ALGORITHM_PARAMETERS Common defaults; no algorithmic iteration is hidden here.
assert(isfield(params,'x0'),'Supply the common initial point params.x0.');
if ~isfield(params,'mu'), params.mu = .8; end
if ~isfield(params,'rho0'), params.rho0 = 1; end
if ~isfield(params,'tol'), params.tol = 1e-6; end
if ~isfield(params,'max_iter'), params.max_iter = 4000; end
if ~isfield(params,'K'), params.K = 5; end
assert(params.mu>0 && params.mu<1,'mu must belong to (0,1).');
assert(params.rho0>0 && params.max_iter>=0,'Invalid stepsize or iteration cap.');
end

function projected = project_onto_halfspace(normal,base,point,scale)
%PROJECT_ONTO_HALFSPACE Projection onto {z: <normal,z-base> <= 0}.
% The scale argument only guards a numerically zero normal.
if nargin<4, scale = max([1,norm(base),norm(point)]); end
if norm(normal)<=1e-12*scale
    projected = point;
else
    projected = point-max(0,normal'*(point-base))/(normal'*normal)*normal;
end
end
