function [x_history, errors, rho_history, time_history, info] = VDS2026(F, P_C, params)
%VDS2026 Xie--Li, CNSNS 163 (2026), 110918, Algorithm 3.1 (viscosity).
% Inputs: F, P_C, and params.x0, rho0, mu, tol, max_iter, L.
% Outputs: iterates (one point per row), projected residuals, stepsizes,
%          elapsed times, and iteration/evaluation counts.
% Error = norm(x - P_C(x - F(x))); j=1 is the first completed update.

%% Parameters and initialization
params = algorithm_parameters(params);
assert(isfield(params,'L') && params.L>0,'An initialization bound L is required.');
if ~isfield(params,'inertial_cap'), params.inertial_cap = .5; end
if ~isfield(params,'eta'), params.eta = @(j)1/(j+2); end
if ~isfield(params,'epsilon'), params.epsilon = @(j)1/(j+2)^2; end
if ~isfield(params,'g'), params.g = @(z)z/20; end
x = params.x0(:);
previous = x;
tau = params.rho0;
lambda = .99*2/(1+params.mu)*min(tau,params.mu/params.L);
kappa = .99*tau*params.L;
mu = params.mu;
max_iter = params.max_iter;
tol = params.tol;
dimension = numel(x);
x_history = zeros(max_iter+1, dimension);
errors = zeros(max_iter+1, 1);
rho_history = zeros(max_iter+1, 1);
time_history = zeros(max_iter+1, 1);
counter_history = zeros(max_iter+1, 3);
F_calls = 0; C_projections = 0; T_projections = 0;
iteration = 0;
% Initial residual; F(x) is reused in the first prediction step.
Fx = F(x); F_calls = F_calls + 1;
projected = P_C(x-Fx); C_projections = C_projections + 1;
x_history(1,:) = x';
errors(1) = norm(x-projected);
rho_history(1) = tau;
time_history(1) = 0; % The common initial point is recorded at time zero.
counter_history(1,:) = [F_calls,C_projections,T_projections];

% Time completed updates, including their residual monitoring.
% The shared initial residual and history setup are outside this timer.
t_start = tic;

%% Main iteration
while iteration<max_iter && errors(iteration+1)>tol
    j = iteration+1;
    % Step 1: adaptive inertia and extrapolated point u_j.
    eta = params.eta(j);
    difference_x = norm(x-previous);
    if difference_x>0
        inertia = min(params.inertial_cap,params.epsilon(j)/difference_x);
    else
        inertia = params.inertial_cap;
    end
    u = x+inertia*(x-previous);
    if isequal(u,x), Fu = Fx;
    else, Fu = F(u); F_calls = F_calls+1; end

    % Step 2: first projection with tau_j.
    y = P_C(u-tau*Fu); C_projections = C_projections+1;
    Fy = F(y); F_calls = F_calls+1;
    if isequal(u,y)
        x_next = y;
    else
        % Step 3: half-space correction with the DISTINCT step lambda_j.
        normal = u-tau*Fu-y;
        correction_point = u-lambda*Fy;
        scale = max([1,norm(u),tau*norm(Fu),norm(y)]);
        w = project_onto_halfspace(normal,y,correction_point,scale);
        T_projections = T_projections+1;
        % Step 4: viscosity update x_{j+1}=eta_j g(w_j)+(1-eta_j)w_j.
        x_next = eta*params.g(w)+(1-eta)*w;
    end

    % Step 5: update BOTH stepsizes for the next iteration.
    difference = norm(Fu-Fy);
    if difference>0
        ratio = norm(u-y)/difference;
        tau_next = min(mu*ratio,tau);
        lambda_next = min(kappa*ratio,lambda);
    else
        tau_next = tau; lambda_next = lambda;
    end
    previous = x; x = x_next;
    tau = tau_next; lambda = lambda_next; iteration = iteration+1;
    % Store the completed iterate and its common residual.
    Fx = F(x); F_calls = F_calls + 1;
    projected = P_C(x-Fx); C_projections = C_projections + 1;
    x_history(iteration+1,:) = x';
    errors(iteration+1) = norm(x-projected);
    rho_history(iteration+1) = tau;
    time_history(iteration+1) = toc(t_start);
    counter_history(iteration+1,:) = [F_calls,C_projections,T_projections];
end

%% Return the actual history (no padding after termination)
last = iteration+1;
x_history = x_history(1:last,:);
errors = errors(1:last);
rho_history = rho_history(1:last);
time_history = time_history(1:last);
info.method = 'VDS2026';
info.K = 0;
info.updates = iteration;
info.operatorCalls = F_calls;
info.constraintProjections = C_projections;
info.halfspaceProjections = T_projections;
info.residual = errors(end);
info.seconds = time_history(end);
info.success = errors(end)<=tol;
info.finalRho = rho_history(end);
info.counter_history = counter_history(1:last,:);
end

function params = algorithm_parameters(params)
%ALGORITHM_PARAMETERS Common defaults; no algorithmic iteration is hidden here.
assert(isfield(params,'x0'),'Supply the common initial point params.x0.');
if ~isfield(params,'mu'), params.mu = .8; end
if ~isfield(params,'rho0'), params.rho0 = 1; end
if ~isfield(params,'tol'), params.tol = 1e-6; end
if ~isfield(params,'max_iter'), params.max_iter = 4000; end
if ~isfield(params,'K'), params.K = 5; end
assert(params.mu>0 && params.mu<1,'mu must belong to (0,1).');
assert(params.rho0>0 && params.max_iter>=0,'Invalid stepsize or iteration cap.');
end

function projected = project_onto_halfspace(normal,base,point,scale)
%PROJECT_ONTO_HALFSPACE Projection onto {z: <normal,z-base> <= 0}.
% The scale argument only guards a numerically zero normal.
if nargin<4, scale = max([1,norm(base),norm(point)]); end
if norm(normal)<=1e-12*scale
    projected = point;
else
    projected = point-max(0,normal'*(point-base))/(normal'*normal)*normal;
end
end
