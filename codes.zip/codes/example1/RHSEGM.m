function [x_history, errors, rho_history, time_history, info] = RHSEGM(F, P_C, params)
%RHSEGM Restarted Halpern Subgradient Extragradient Method (paper Algorithm 1).
% Inputs: F, P_C, and params.x0, rho0, mu, tol, max_iter, K.
% Outputs: iterates (one point per row), projected residuals, stepsizes,
%          elapsed times, and iteration/evaluation counts.
% Error = norm(x - P_C(x - F(x))); j=1 is the first completed update.

%% Parameters and initialization
params = algorithm_parameters(params);
K = params.K;
assert(K>=1 && K==fix(K),'K must be a positive integer.');
x = params.x0(:);
rho = params.rho0;
n = 0; % restart-cycle index
mu = params.mu;
max_iter = params.max_iter;
tol = params.tol;
dimension = numel(x);
x_history = zeros(max_iter+1, dimension);
errors = zeros(max_iter+1, 1);
rho_history = zeros(max_iter+1, 1);
time_history = zeros(max_iter+1, 1);
counter_history = zeros(max_iter+1, 3);
F_calls = 0; C_projections = 0; T_projections = 0;
iteration = 0;
% Initial residual; F(x) is reused in the first prediction step.
Fx = F(x); F_calls = F_calls + 1;
projected = P_C(x-Fx); C_projections = C_projections + 1;
x_history(1,:) = x';
errors(1) = norm(x-projected);
rho_history(1) = rho;
time_history(1) = 0; % The common initial point is recorded at time zero.
counter_history(1,:) = [F_calls,C_projections,T_projections];

% Time completed updates, including their residual monitoring.
% The shared initial residual and history setup are outside this timer.
t_start = tic;

%% Main iteration
while iteration<max_iter && errors(iteration+1)>tol
    % Start cycle n: x_anchor=x^{n,0}; rho is inherited from cycle n-1.
    x_anchor = x;
    for k = 0:K-1
        if iteration>=max_iter || errors(iteration+1)<=tol, break; end

        % Step 1: y^{n,k}=P_C(x^{n,k}-rho_{n,k} F(x^{n,k})).
        if rho==1
            y = projected;
        else
            y = P_C(x-rho*Fx); C_projections = C_projections + 1;
        end
        Fy = F(y); F_calls = F_calls + 1;

        % Step 2: compute rho_{n,k+1}; the correction still uses rho_{n,k}.
        difference = norm(Fx-Fy);
        if difference>0
            rho_next = min(mu*norm(x-y)/difference,rho);
        else
            rho_next = rho;
        end

        % Step 3: T^{n,k}={z: <x-rho*Fx-y,z-y> <= 0}.
        normal = x-rho*Fx-y;

        % Step 4: d^{n,k+1}=P_T(x-rho_{n,k} F(y^{n,k})).
        correction_point = x-rho*Fy;
        scale = max([1,norm(x),rho*norm(Fx),norm(y)]);
        d = project_onto_halfspace(normal,y,correction_point,scale);
        T_projections = T_projections + 1;

        % Step 5: Halpern update with the CURRENT CYCLE anchor.
        x = (1/(k+2))*x_anchor+((k+1)/(k+2))*d;
        rho = rho_next;
        iteration = iteration+1;
        % Store the completed iterate and its common residual.
        Fx = F(x); F_calls = F_calls + 1;
        projected = P_C(x-Fx); C_projections = C_projections + 1;
        x_history(iteration+1,:) = x';
        errors(iteration+1) = norm(x-projected);
        rho_history(iteration+1) = rho;
        time_history(iteration+1) = toc(t_start);
        counter_history(iteration+1,:) = [F_calls,C_projections,T_projections];
    end
    % Restart: x^{n+1,0}=x^{n,K}; reset k and retain rho_{n,K}.
    n = n+1;
end

%% Return the actual history (no padding after termination)
last = iteration+1;
x_history = x_history(1:last,:);
errors = errors(1:last);
rho_history = rho_history(1:last);
time_history = time_history(1:last);
info.method = 'RHSEGM';
info.K = K;
info.updates = iteration;
info.operatorCalls = F_calls;
info.constraintProjections = C_projections;
info.halfspaceProjections = T_projections;
info.residual = errors(end);
info.seconds = time_history(end);
info.success = errors(end)<=tol;
info.finalRho = rho_history(end);
info.counter_history = counter_history(1:last,:);
end

function params = algorithm_parameters(params)
%ALGORITHM_PARAMETERS Common defaults; no algorithmic iteration is hidden here.
assert(isfield(params,'x0'),'Supply the common initial point params.x0.');
if ~isfield(params,'mu'), params.mu = .8; end
if ~isfield(params,'rho0'), params.rho0 = 1; end
if ~isfield(params,'tol'), params.tol = 1e-6; end
if ~isfield(params,'max_iter'), params.max_iter = 4000; end
if ~isfield(params,'K'), params.K = 5; end
assert(params.mu>0 && params.mu<1,'mu must belong to (0,1).');
assert(params.rho0>0 && params.max_iter>=0,'Invalid stepsize or iteration cap.');
end

function projected = project_onto_halfspace(normal,base,point,scale)
%PROJECT_ONTO_HALFSPACE Projection onto {z: <normal,z-base> <= 0}.
% The scale argument only guards a numerically zero normal.
if nargin<4, scale = max([1,norm(base),norm(point)]); end
if norm(normal)<=1e-12*scale
    projected = point;
else
    projected = point-max(0,normal'*(point-base))/(normal'*normal)*normal;
end
end
