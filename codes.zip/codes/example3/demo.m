%% Example 4.3: one fixed initialization, two figures, and an Excel table.
clearvars; clc; close all;
example_number = 3;
seed = 11;                 % Change this one value to choose another initial point.
mu = .8;
tol = 1e-6; max_iter = 4000;
rng(seed,'twister');        % Called ONCE, before generating x0.

%% Problem and common initial point
dimension = 100;
J = kron(speye(dimension/2),[0,-1;1,0]);
A = .01*speye(dimension)+J;
center = .2*ones(dimension,1);
F = @(x)(exp(-(x'*x)/dimension)+.1)*(A*(x-center));
P_C = @(x)min(1,max(-1,x));
L = 2.01*sqrt(1+.01^2);
x_star = center;
x0 = 2*rand(dimension,1)-1;
problem_data = struct('A',A,'Q',speye(dimension)/dimension,'q',-A*center,'beta',.1,'center',center);

%% Output folders identify this single initialization
here = fileparts(mfilename('fullpath'));
addpath(here);
mu_tag = strrep(sprintf('%.3g',mu),'.','p');
run_folder = fullfile(here,'results',sprintf('seed%d_mu%s',seed,mu_tag));
figure_folder = fullfile(run_folder,'figures');
table_folder = fullfile(run_folder,'tables');
data_folder = fullfile(run_folder,'data');
if ~exist(figure_folder,'dir'), mkdir(figure_folder); end
if ~exist(table_folder,'dir'), mkdir(table_folder); end
if ~exist(data_folder,'dir'), mkdir(data_folder); end

%% Algorithm functions and parameter settings
% RHSEGM is tested ONLY with K=5 and K=20.
solvers = {@WISEGM,@DIS,@HSEGM,@Y2022,...
    @RHSEGM,@RHSEGM,@HTS2025,@VDS2026,@MDS2026};
labels = {'WISEGM','DIS','HSEGM','Y2022',...
    'RH5','RH20','HTS2025','VDS2026','MDS2026'};
periods = [0,0,0,0,5,20,0,0,0];
results = struct([]);
for algorithm_index = 1:numel(solvers)
    params = struct('x0',x0,'rho0',1,'mu',mu,'tol',tol,...
        'max_iter',max_iter,'L',L,'K',periods(algorithm_index));
    switch labels{algorithm_index}
        case 'WISEGM'
            params.inertial_cap = .3;
        case 'DIS'
            params.theta = 1; params.delta = .05; params.relaxation = .2;
        case 'HSEGM'
            params.alpha = @(j)1/(j+1);
        case 'Y2022'
            params.alpha = @(j)1/(j+2);
        case 'HTS2025'
            params.alpha = @(j)1/(j+1);
            params.theta = @(j)(j+1)^(-2.5); params.delta = @(j)-(j+1)^(-2.5);
            params.tau = min(1.5,(1+1/mu)/2); params.gamma = .8;
            params.gamma_j = @(j)1/(j+1); params.rho_j = @(j)1/(j+2)^2;
        case {'VDS2026','MDS2026'}
            params.inertial_cap = .5;
            params.eta = @(j)1/(j+2); params.epsilon = @(j)1/(j+2)^2;
            params.g = @(z)z/20; params.beta = @(j).9*(1-1/(j+2));
    end
    solver = solvers{algorithm_index};
    warm = params; warm.max_iter = min(100,max_iter); warm.tol = -1;
    [~,~,~,~,warm_info] = solver(F,P_C,warm); %#ok<ASGLU>
    % Same output interface in warm-up and measurement; actual run starts at x0.
    [x_history,errors,rho_history,time_history,info] = solver(F,P_C,params);
    % Every curve starts at the same (iteration,time,error)=(0,0,R(x0)).
    assert(isequal(x_history(1,:)',x0));
    assert(time_history(1)==0 && all(diff(time_history)>=0));
    if algorithm_index==1, initial_error=errors(1); end
    assert(abs(errors(1)-initial_error)<=1e-14*max(1,initial_error));
    record = rmfield(info,'counter_history');
    record.label = labels{algorithm_index}; record.seed = seed; record.mu = mu;
    record.x = x_history(end,:)';
    record.history = [(0:info.updates)',info.counter_history(:,1:2),errors,...
        vecnorm(x_history-x_star',2,2),rho_history,time_history];
    if algorithm_index==1, results=record; else, results(algorithm_index)=record; end %#ok<SAGROW>
end

%% One table for THIS seed, without averaging across different initial points
comparison = table(string(labels(:)),[results.updates]',[results.seconds]',...
    [results.residual]',double([results.success]'),...
    'VariableNames',{'Algorithm','Iterations','CPU_Time_s','Final_Error','Success'});
fprintf('\nExample 4.%d: ONE run per algorithm, seed=%d (twister), mu=%.2f\n',...
    example_number,seed,mu);
fprintf('All methods use the same x0. Success: 1=R(x)<=tol, 0=iteration limit.\n');
disp(comparison);

%% Save the numerical table to Excel, including the seed and initial vector
excel_file = fullfile(table_folder,sprintf('comparison_seed%d.xlsx',seed));
writetable(comparison,excel_file,'Sheet','Results','Range','A6',...
    'WriteMode','overwritesheet','AutoFitWidth',true);
settings = {'Example',example_number,'Seed',seed;...
    'mu',mu,'Tolerance',tol;...
    'MaxIter',max_iter,'Runs',1};
writecell(settings,excel_file,'Sheet','Results','Range','A1','AutoFitWidth',false);
writecell({'Success: 1=converged, 0=limit'},excel_file,'Sheet','Results',...
    'Range','A4','AutoFitWidth',false);
initial_point = table((1:dimension)',x0,'VariableNames',{'Coordinate','InitialValue'});
writetable(initial_point,excel_file,'Sheet','InitialPoint',...
    'WriteMode','overwritesheet','AutoFitWidth',true);
% Verify the saved numerical cells using MATLAB itself.
table_range = sprintf('A6:E%d',6+height(comparison));
saved_comparison = readtable(excel_file,'Sheet','Results','Range',table_range);
assert(isequal(saved_comparison.Iterations,comparison.Iterations));
assert(all(abs(saved_comparison.Final_Error-comparison.Final_Error)<=1e-14));

metadata = struct('example',example_number,'seed',seed,'generator','twister',...
    'mu',mu,'tol',tol,'maxIterations',max_iter,'runsPerAlgorithm',1,...
    'created',datestr(now,31),'matlabVersion',version,'computer',computer,...
    'errorDefinition','norm(x-P_C(x-F(x)))',...
    'timeOrigin','Initial point at t=0; timer starts after initial residual/setup',...
    'horizontalScale','linear');
save(fullfile(data_folder,'raw_results.mat'),'results','comparison','metadata','x0','problem_data');
summary = rmfield(results,{'x','history'});
fid=fopen(fullfile(data_folder,'summary.json'),'w'); assert(fid>=0);
fprintf(fid,'%s',jsonencode(struct('metadata',metadata,'results',summary),'PrettyPrint',true)); fclose(fid);

%% Display exactly TWO comparison figures, both for the same seed as the table
figure_visibility = 'on';
if strcmp(getenv('RHSEGM_BATCH'),'1'), figure_visibility='off'; end
fig_iterations = figure('Visible',figure_visibility,'Color','w','Units','inches',...
    'Position',[1,1,6.8,5.0],'Name',sprintf('Example 4.%d | seed %d | Iterations',example_number,seed));
ax_iterations = axes(fig_iterations);
draw_comparison(ax_iterations,results,labels,1,seed,mu,tol);
legend(ax_iterations,labels,'Location','southoutside','NumColumns',3,...
    'Interpreter','none','FontSize',9);
add_initial_zoom(ax_iterations,results,labels,1,seed,mu,tol);
print(fig_iterations,fullfile(figure_folder,'error_vs_iterations.eps'),'-depsc2','-painters');

fig_time = figure('Visible',figure_visibility,'Color','w','Units','inches',...
    'Position',[8,1,6.8,5.0],'Name',sprintf('Example 4.%d | seed %d | CPU time',example_number,seed));
ax_time = axes(fig_time);
draw_comparison(ax_time,results,labels,2,seed,mu,tol);
legend(ax_time,labels,'Location','southoutside','NumColumns',3,...
    'Interpreter','none','FontSize',9);
add_initial_zoom(ax_time,results,labels,2,seed,mu,tol);
print(fig_time,fullfile(figure_folder,'error_vs_time.eps'),'-depsc2','-painters');

% An invisible two-panel PDF is saved only for the main TeX figure.
combined = figure('Visible','off','Color','w','Units','inches','Position',[1,1,8.4,4.5]);
layout = tiledlayout(combined,1,2,'TileSpacing','compact','Padding','compact');
ax = nexttile(layout); handles=draw_comparison(ax,results,labels,1,seed,mu,tol);
lg=legend(ax,handles,labels,'NumColumns',3,'Interpreter','none','FontSize',8);
lg.Layout.Tile='south';
ax_time_combined=nexttile(layout);
draw_comparison(ax_time_combined,results,labels,2,seed,mu,tol);
% The paper reports the common seed and stepsize parameter in the experimental setup.
set([ax.Title,ax_time_combined.Title],'String','');
add_initial_zoom(ax,results,labels,1,seed,mu,tol);
add_initial_zoom(ax_time_combined,results,labels,2,seed,mu,tol);
exportgraphics(combined,fullfile(figure_folder,'convergence.pdf'),'ContentType','vector');
close(combined);
assert(numel(findall(groot,'Type','figure'))==2,'The demo should leave two comparison figures.');
fprintf('EPS figures: %s\nExcel table: %s\n',figure_folder,excel_file);

function handles=draw_comparison(ax,results,labels,panel,seed,mu,tol)
% Plot one panel; no experiment or algorithm is hidden in this helper.
hold(ax,'on'); colors=lines(numel(labels)); styles={'-','--',':','-.'};
colors(strcmp(labels,'RH5'),:)=[.8,0,0];
handles=gobjects(numel(labels),1); maximum_error=0; minimum_error=tol;
for k=1:numel(labels)
    h=results(k).history; maximum_error=max(maximum_error,max(h(:,4)));
    minimum_error=min(minimum_error,min(h(h(:,4)>0,4)));
    if panel==1, horizontal=h(:,1); else, horizontal=h(:,7); end
    width=1.2; % Keep the actual initial point at horizontal=0.
    if strcmp(labels{k},'RH5'), width=2; end
    handles(k)=semilogy(ax,horizontal,max(h(:,4),realmin),...
        'Color',colors(k,:),'LineStyle',styles{1+mod(k-1,4)},'LineWidth',width);
end
yline(ax,tol,'k:','HandleVisibility','off');
set(ax,'XScale','linear','YScale','log','FontName','Times New Roman','FontSize',11);
if panel==1, last_values=arrayfun(@(r)r.history(end,1),results);
else, last_values=arrayfun(@(r)r.history(end,7),results); end
xlim(ax,[0,max(max(last_values),eps)]);
assert(ax.XLim(1)==0 && strcmp(ax.XScale,'linear'));
ylim(ax,[min(tol/2,minimum_error/2),10^ceil(log10(maximum_error))]);
yticks(ax,10.^(floor(log10(tol)):2:ceil(log10(maximum_error))));
grid(ax,'on'); box(ax,'on'); ax.XMinorGrid='off'; ax.YMinorGrid='off';
ylabel(ax,'Error R(x)');
if panel==1, xlabel(ax,'Iterations'); else, xlabel(ax,'CPU Time (s)'); end
title(ax,sprintf('seed=%d, mu=%.2f',seed,mu));
end


function add_initial_zoom(main_ax,results,labels,panel,seed,mu,tol)
% Keep the full history in the main axes; enlarge its initial phase in an inset.
drawnow;
box_pixels=getpixelposition(main_ax,true);
inset=axes('Parent',ancestor(main_ax,'figure'),'Units','pixels',...
    'Position',[box_pixels(1)+.50*box_pixels(3),box_pixels(2)+.70*box_pixels(4),...
                .44*box_pixels(3),.27*box_pixels(4)]);
set(inset,'Units','normalized');
draw_comparison(inset,results,labels,panel,seed,mu,tol);
if panel==1
    zoom_limit=min(200,max(arrayfun(@(r)r.history(end,1),results)));
else
    zoom_limit=.1*max(arrayfun(@(r)r.history(end,7),results));
end
xlim(inset,[0,max(zoom_limit,eps)]);
xticks(inset,[0,zoom_limit/2,zoom_limit]);
xtickformat(inset,'%.2g');
yticks(inset,[tol,sqrt(tol),1]);
set(inset,'FontSize',6.5,'Color','w','LineWidth',.6);
inset.XAxis.Exponent=0; % Show the actual time in seconds, without an offset exponent.
xticklabels(inset,compose('%.3g',[0,zoom_limit/2,zoom_limit]));
xlabel(inset,''); ylabel(inset,'');
title(inset,'Initial phase','FontSize',7,'FontWeight','normal');
end
